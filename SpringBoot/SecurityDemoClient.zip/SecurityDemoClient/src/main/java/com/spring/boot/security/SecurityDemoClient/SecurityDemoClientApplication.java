package com.spring.boot.security.SecurityDemoClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityDemoClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityDemoClientApplication.class, args);
	}
}
